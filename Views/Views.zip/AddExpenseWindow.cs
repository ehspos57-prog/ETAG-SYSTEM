﻿namespace ETAG_ERP.Views
{
    internal class AddExpenseWindow
    {
        public AddExpenseWindow()
        {
        }
    }
}