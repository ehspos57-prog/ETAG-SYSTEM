﻿using System.ComponentModel;

namespace ETAG_ERP.Views
{
    public class LedgerViewModelBase
    {
        public event PropertyChangedEventHandler? PropertyChanged;
    }
}