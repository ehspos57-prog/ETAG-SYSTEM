﻿namespace ETAG_ERP.Views
{
    internal class InvoiceDetailsView
    {
        private Invoice selectedInvoice;
        private Invoice selectedInvoice1;

        public InvoiceDetailsView(Invoice selectedInvoice)
        {
            this.selectedInvoice = selectedInvoice;
        }

        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}