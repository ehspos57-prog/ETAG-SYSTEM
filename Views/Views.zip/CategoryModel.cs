﻿namespace ETAG_ERP.Views
{
    internal class CategoryModel
    {
    }
}