﻿namespace ETAG_ERP.Views
{
    internal class ReceivingNoteViewModel
    {
        public ReceivingNoteViewModel()
        {
        }
    }
}