﻿using System.ComponentModel;

namespace ETAG_ERP.Views
{
    public class ETAGBaseViewModelBase
    {
        public event PropertyChangedEventHandler PropertyChanged;
    }
}