﻿namespace ETAG_ERP.Views
{
    internal class CategoryTitle
    {
        public static string Text { get; internal set; }
    }
}